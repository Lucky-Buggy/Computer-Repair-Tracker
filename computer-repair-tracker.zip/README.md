# Computer Repair Tracker

A repair-ticket tracker for a computer repair shop: dashboard stats, a
searchable/filterable ticket list, and add/edit/delete for repair tickets.

- **Frontend:** plain HTML, CSS and JavaScript (`artifacts/computer-repair-tracker`) — no
  React, no TypeScript, no Tailwind. Vite is only used as a dev server and a
  bundler; it does not require any framework.
- **Backend:** Node.js + Express + TypeScript (`artifacts/api-server`)
- **Database:** PostgreSQL, accessed with Drizzle ORM (`lib/db`)

This project was originally built on Replit and has since had its
Replit-only files removed so it can be developed anywhere (including
Acode) and hosted anywhere.

## Project layout

```
artifacts/
  computer-repair-tracker/   the website (HTML/CSS/JS)
  api-server/                the backend API (Express)
lib/
  db/                        database schema (Drizzle) and connection
  api-zod/                   shared request/response validation (Zod)
  api-client-react/          generated API client (not used by the plain-JS frontend)
lib/api-spec/                the OpenAPI spec these are generated from
scripts/                     small workspace-level scripts
```

## Requirements

- Node.js 20 or newer
- [pnpm](https://pnpm.io) (this is a pnpm workspace; npm/yarn are not supported —
  the root `package.json` actively blocks them)
- A PostgreSQL database

## Environment variables

Create a `.env` file (or otherwise set these in your shell) — **never commit
real values for these**:

| Variable | Used by | Required | Notes |
|---|---|---|---|
| `DATABASE_URL` | `lib/db`, so both the API server and any DB scripts | Yes | PostgreSQL connection string |
| `PORT` | `artifacts/api-server` | Yes | Port the API server listens on, e.g. `8080` |
| `PORT` | `artifacts/computer-repair-tracker` (Vite) | No | Defaults to `5173` if not set |
| `BASE_PATH` | `artifacts/computer-repair-tracker` (Vite) | No | Defaults to `/` if not set |
| `API_PORT` | `artifacts/computer-repair-tracker` (Vite dev proxy) | No | Defaults to `8080`. Only matters when running the frontend dev server by itself — it tells it where to forward `/api` requests. |
| `NODE_ENV` | `artifacts/api-server` | No | Set to `production` for production logging behavior |
| `LOG_LEVEL` | `artifacts/api-server` | No | Defaults to `info` |

## Install

```bash
pnpm install
```

## Set up the database

```bash
pnpm --filter db push
```

This creates the `repair_tickets` table from the schema in `lib/db/src/schema/repairs.ts`.
The API server will automatically seed a few example tickets the first time
it starts against an empty table (`artifacts/api-server/src/lib/seed-repairs.ts`).

## Running it

**Option 1 — one process (recommended, matches how it runs in production):**

```bash
pnpm --filter @workspace/computer-repair-tracker run build
pnpm --filter @workspace/api-server run build
pnpm --filter @workspace/api-server run start
```

Then open `http://localhost:8080` (or whatever `PORT` you set for the API
server). The API server serves the built frontend itself, so there's only
one process and one port to worry about — this is the part that used to be
handled by Replit's own router.

**Option 2 — two processes, with live-reload while you edit the frontend:**

Terminal 1:
```bash
PORT=8080 pnpm --filter @workspace/api-server run dev
```

Terminal 2:
```bash
pnpm --filter @workspace/computer-repair-tracker run dev
```

The frontend dev server proxies `/api` requests to `http://localhost:8080`
(or whatever `API_PORT` you set). Open the URL Vite prints (defaults to
`http://localhost:5173`).

## Original Replit ports (for reference)

These aren't needed anywhere else, but are noted here since the file that
used to record them (`.replit`) has been removed:

- API server: `8080`
- Frontend dev server: `23472`

## Notes on the `lib/` folder

`lib/api-zod` and `lib/api-client-react` are a generated OpenAPI-based
client (built with [Orval](https://orval.dev), spec in `lib/api-spec`). They
were originally intended for a React frontend. The plain-JS frontend in
`artifacts/computer-repair-tracker/src/api.js` does **not** use them — it
just calls `fetch()` directly. They're kept because `lib/api-zod`'s types
are also used by `artifacts/api-server` for request/response validation.
You can ignore `lib/api-client-react` unless you build another frontend
later.

## Deploying elsewhere

`scripts/post-merge.sh` (`pnpm install --frozen-lockfile && pnpm --filter db push`)
used to run automatically after each `git pull` via Replit. Outside Replit
there's no automatic hook for that, so run it by hand after pulling changes
that touch dependencies or the database schema:

```bash
bash scripts/post-merge.sh
```
