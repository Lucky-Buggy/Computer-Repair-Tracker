import { createInsertSchema } from "drizzle-zod";
import { date, pgEnum, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const repairStatuses = [
  "Pending",
  "Diagnosing",
  "Repairing",
  "Ready",
  "Completed",
] as const;

export const repairStatusEnum = pgEnum("repair_status", repairStatuses);

export const repairTicketsTable = pgTable("repair_tickets", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull(),
  contact: text("contact"),
  deviceType: text("device_type").notNull(),
  brand: text("brand"),
  model: text("model"),
  dateReceived: date("date_received", { mode: "string" }).notNull(),
  problem: text("problem").notNull(),
  status: repairStatusEnum("status").notNull().default("Pending"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertRepairTicketSchema = createInsertSchema(repairTicketsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertRepairTicket = z.infer<typeof insertRepairTicketSchema>;
export type RepairTicket = typeof repairTicketsTable.$inferSelect;