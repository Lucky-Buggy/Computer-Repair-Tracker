import { Router, type IRouter } from "express";
import healthRouter from "./health";
import repairsRouter from "./repairs";

const router: IRouter = Router();

router.use(healthRouter);
router.use(repairsRouter);

export default router;
