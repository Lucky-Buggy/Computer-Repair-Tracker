import { and, count, desc, eq, ilike, or } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreateRepairBody,
  CreateRepairResponse,
  DeleteRepairParams,
  DeleteRepairResponse,
  GetRepairParams,
  GetRepairResponse,
  GetRepairStatsResponse,
  ListRepairsQueryParams,
  ListRepairsResponse,
  UpdateRepairBody,
  UpdateRepairParams,
  UpdateRepairResponse,
} from "@workspace/api-zod";
import { db, repairTicketsTable } from "@workspace/db";

const router: IRouter = Router();
const ticketNumberOffset = 1000;

function toRepairDto(row: typeof repairTicketsTable.$inferSelect) {
  return {
    ...row,
    ticketNumber: row.id + ticketNumberOffset,
  };
}

function dateOnly(value: Date): string {
  return value.toISOString().slice(0, 10);
}

router.get("/repairs", async (req, res): Promise<void> => {
  const query = ListRepairsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const filters = [];
  if (query.data.status) {
    filters.push(eq(repairTicketsTable.status, query.data.status));
  }

  const search = query.data.search?.trim().replace(/^#/, "").trim();
  if (search) {
    const pattern = `%${search}%`;
    const searchConditions = [
      ilike(repairTicketsTable.customerName, pattern),
      ilike(repairTicketsTable.contact, pattern),
      ilike(repairTicketsTable.deviceType, pattern),
      ilike(repairTicketsTable.brand, pattern),
      ilike(repairTicketsTable.model, pattern),
      ilike(repairTicketsTable.problem, pattern),
    ];

    if (/^\d+$/.test(search)) {
      const ticketNumber = Number(search);
      const id = ticketNumber - ticketNumberOffset;
      if (Number.isSafeInteger(id) && id > 0) {
        searchConditions.push(eq(repairTicketsTable.id, id));
      }
    }

    filters.push(or(...searchConditions));
  }

  const rows = await db
    .select()
    .from(repairTicketsTable)
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(desc(repairTicketsTable.createdAt), desc(repairTicketsTable.id));

  const repairs = rows.map(toRepairDto);
  ListRepairsResponse.parse(repairs);
  res.json(repairs);
});

router.post("/repairs", async (req, res): Promise<void> => {
  const input = CreateRepairBody.safeParse(req.body);
  if (!input.success) {
    res.status(400).json({ error: input.error.message });
    return;
  }

  const [row] = await db
    .insert(repairTicketsTable)
    .values({
      ...input.data,
      contact: input.data.contact ?? null,
      brand: input.data.brand ?? null,
      model: input.data.model ?? null,
      dateReceived: dateOnly(input.data.dateReceived),
    })
    .returning();

  const repair = toRepairDto(row);
  CreateRepairResponse.parse(repair);
  res.status(201).json(repair);
});

router.get("/repairs/:id", async (req, res): Promise<void> => {
  const params = GetRepairParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [row] = await db
    .select()
    .from(repairTicketsTable)
    .where(eq(repairTicketsTable.id, params.data.id));

  if (!row) {
    res.status(404).json({ error: "Repair ticket not found" });
    return;
  }

  const repair = toRepairDto(row);
  GetRepairResponse.parse(repair);
  res.json(repair);
});

router.patch("/repairs/:id", async (req, res): Promise<void> => {
  const params = UpdateRepairParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const input = UpdateRepairBody.safeParse(req.body);
  if (!input.success) {
    res.status(400).json({ error: input.error.message });
    return;
  }

  if (Object.keys(input.data).length === 0) {
    res.status(400).json({ error: "At least one repair field is required" });
    return;
  }

  const [row] = await db
    .update(repairTicketsTable)
    .set({
      customerName: input.data.customerName,
      contact: input.data.contact,
      deviceType: input.data.deviceType,
      brand: input.data.brand,
      model: input.data.model,
      dateReceived: input.data.dateReceived
        ? dateOnly(input.data.dateReceived)
        : undefined,
      problem: input.data.problem,
      status: input.data.status,
      updatedAt: new Date(),
    })
    .where(eq(repairTicketsTable.id, params.data.id))
    .returning();

  if (!row) {
    res.status(404).json({ error: "Repair ticket not found" });
    return;
  }

  const repair = toRepairDto(row);
  UpdateRepairResponse.parse(repair);
  res.json(repair);
});

router.delete("/repairs/:id", async (req, res): Promise<void> => {
  const params = DeleteRepairParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [row] = await db
    .delete(repairTicketsTable)
    .where(eq(repairTicketsTable.id, params.data.id))
    .returning({ id: repairTicketsTable.id });

  if (!row) {
    res.status(404).json({ error: "Repair ticket not found" });
    return;
  }

  const result = { deleted: true, id: row.id };
  DeleteRepairResponse.parse(result);
  res.json(result);
});

router.get("/dashboard/stats", async (_req, res): Promise<void> => {
  const groupedCounts = await db
    .select({ status: repairTicketsTable.status, total: count() })
    .from(repairTicketsTable)
    .groupBy(repairTicketsTable.status);

  const stats = {
    total: 0,
    pending: 0,
    diagnosing: 0,
    repairing: 0,
    ready: 0,
    completed: 0,
  };

  for (const group of groupedCounts) {
    const key = group.status.toLowerCase() as keyof typeof stats;
    stats[key] = group.total;
    stats.total += group.total;
  }

  res.json(GetRepairStatsResponse.parse(stats));
});

export default router;