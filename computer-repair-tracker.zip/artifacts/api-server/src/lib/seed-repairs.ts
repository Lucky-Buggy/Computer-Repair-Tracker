import { count, sql } from "drizzle-orm";
import { db, repairTicketsTable } from "@workspace/db";

export async function seedRepairTicketsIfEmpty(): Promise<void> {
  await db.transaction(async (tx) => {
    await tx.execute(sql`LOCK TABLE ${repairTicketsTable} IN EXCLUSIVE MODE`);

    const [result] = await tx
      .select({ total: count() })
      .from(repairTicketsTable);

    if (result.total > 0) {
      return;
    }

    await tx.insert(repairTicketsTable).values([
      {
        customerName: "Maria Santos",
        contact: null,
        deviceType: "Laptop",
        brand: "Lenovo",
        model: "IdeaPad 3",
        dateReceived: "2026-09-20",
        problem: "Screen flickers and shuts off after a few minutes.",
        status: "Repairing",
      },
      {
        customerName: "Juan dela Cruz",
        contact: null,
        deviceType: "Desktop",
        brand: "Custom",
        model: "Custom build",
        dateReceived: "2026-09-22",
        problem: "Will not power on.",
        status: "Pending",
      },
      {
        customerName: "Ana Reyes",
        contact: null,
        deviceType: "Printer",
        brand: "Canon",
        model: "G3010",
        dateReceived: "2026-09-18",
        problem: "Paper jam and streaky prints.",
        status: "Ready",
      },
    ]);
  });
}