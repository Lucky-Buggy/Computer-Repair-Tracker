import path from "node:path";
import { fileURLToPath } from "node:url";
import fs from "node:fs";
import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

// Outside Replit there is no separate router service stitching the
// frontend and API together, so this server can also serve the built
// frontend directly. This only activates if that build exists — it does
// not change anything about how the API routes below behave, and it does
// not run at all in the normal Replit dev setup (two services, no build
// present yet).
const currentDir = path.dirname(fileURLToPath(import.meta.url));
const frontendDist = path.resolve(
  currentDir,
  "../../computer-repair-tracker/dist/public",
);
const hasFrontendBuild = fs.existsSync(
  path.join(frontendDist, "index.html"),
);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

// Serve the built frontend (see hasFrontendBuild above). Any request that
// is not for /api and does not match a real file falls back to
// index.html, since this is a single-page app.
if (hasFrontendBuild) {
  app.use(express.static(frontendDist));
  app.get(/^\/(?!api).*/, (_req, res) => {
    res.sendFile(path.join(frontendDist, "index.html"));
  });
}

export default app;
