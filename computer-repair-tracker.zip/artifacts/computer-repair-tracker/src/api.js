const apiRoot = "/api";

async function request(path, options = {}) {
  const response = await fetch(`${apiRoot}${path}`, {
    cache: "no-store",
    ...options,
    headers: {
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...options.headers,
    },
  });

  const text = await response.text();
  let data = null;

  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error("The server returned an unreadable response.");
    }
  }

  if (!response.ok) {
    throw new Error(data?.error || `Request failed (${response.status}).`);
  }

  return data;
}

// These requests use the existing repair API and database.
export function listRepairs(search = "", status = "") {
  const params = new URLSearchParams();
  if (search.trim()) params.set("search", search.trim());
  if (status) params.set("status", status);

  const query = params.toString();
  return request(`/repairs${query ? `?${query}` : ""}`);
}

export function getRepair(id) {
  return request(`/repairs/${id}`);
}

export function createRepair(repair) {
  return request("/repairs", {
    method: "POST",
    body: JSON.stringify(repair),
  });
}

export function updateRepair(id, repair) {
  return request(`/repairs/${id}`, {
    method: "PATCH",
    body: JSON.stringify(repair),
  });
}

export function deleteRepair(id) {
  return request(`/repairs/${id}`, { method: "DELETE" });
}

export function getRepairStats() {
  return request("/dashboard/stats");
}