import path from "node:path";
import { fileURLToPath } from "node:url";
import { defineConfig } from "vite";

const appRoot = path.dirname(fileURLToPath(import.meta.url));

// On Replit, PORT and BASE_PATH are always provided by the platform.
// Outside Replit (plain `pnpm dev` on GitHub/Acode/your own machine) they
// usually aren't set, so we fall back to sensible local defaults instead
// of crashing. Setting them still works exactly as before.
const rawPort = process.env.PORT || "5173";
const port = Number(rawPort);
const basePath = process.env.BASE_PATH || "/";

if (!Number.isInteger(port) || port <= 0) {
  throw new Error("PORT must be a valid number.");
}

// The API server's port, for the dev proxy below. Defaults to 8080,
// which matches artifacts/api-server's own default local port.
const apiPort = Number(process.env.API_PORT || 8080);

export default defineConfig({
  base: basePath,
  root: appRoot,
  build: {
    outDir: path.join(appRoot, "dist/public"),
    emptyOutDir: true,
  },
  server: {
    port,
    strictPort: true,
    host: "0.0.0.0",
    allowedHosts: true,
    fs: { strict: true },
    // Forwards /api requests to the backend during `vite dev`. On Replit
    // this is unused because its own router already handles /api; it only
    // matters when running this frontend by itself outside Replit.
    proxy: {
      "/api": {
        target: `http://localhost:${apiPort}`,
        changeOrigin: true,
      },
    },
  },
  preview: {
    port,
    host: "0.0.0.0",
    allowedHosts: true,
  },
});