# Project History

This file is a change log of the Replit → GitHub/Acode conversion. It is
**not a backup** — it cannot restore removed code by itself. The original
Replit project remains on Replit if you need to refer back to it.

## 2026-09-25 — Convert for GitHub / Acode use

### Investigation findings (before any changes were made)

- The project's `artifacts/` folder contains three separate Replit
  "artifacts": `computer-repair-tracker` (the real, deployed website),
  `api-server` (the real backend), and `mockup-sandbox` (Replit's internal
  design-preview tool — never built or deployed as part of the app).
- The real frontend (`artifacts/computer-repair-tracker`) was **already
  plain HTML, CSS and vanilla JavaScript** — no React, TypeScript, JSX/TSX,
  or Tailwind. It only used Vite as a dev server/bundler for native ES
  modules. All of the React/TypeScript/Tailwind code in the project lived
  in `mockup-sandbox`, which was never part of the live site.
- No secrets, API keys, or `.env` files with real values were found
  anywhere in the project. `DATABASE_URL` and `PORT` are read from
  environment variables only.

### Frontend

- No conversion needed — was already vanilla HTML/CSS/JS.
- `artifacts/computer-repair-tracker/vite.config.js`: `PORT` and
  `BASE_PATH` now default to `5173` and `/` instead of throwing when unset,
  so the dev server can run outside Replit (which always set these
  automatically). Behavior is unchanged when they are set.
- `artifacts/computer-repair-tracker/vite.config.js`: added a dev-server
  proxy that forwards `/api` requests to the backend
  (`http://localhost:8080` by default, overridable with `API_PORT`). This
  replaces the routing that Replit's own infrastructure used to provide
  between the two separate services.

### Backend

- `artifacts/api-server/src/app.ts`: added static file serving for the
  built frontend (`artifacts/computer-repair-tracker/dist/public`), with a
  single-page-app fallback to `index.html` for any non-`/api` route. This
  only activates if that build exists, so it does not change anything
  about existing `/api` behavior. All existing routes, validation, and CRUD
  logic in `artifacts/api-server/src/routes/repairs.ts` are unchanged.

### Database

- No changes. Schema (`lib/db/src/schema/repairs.ts`), seed data
  (`artifacts/api-server/src/lib/seed-repairs.ts`), and the `DATABASE_URL`
  connection setup (`lib/db/src/index.ts`) are all untouched.

### Files removed

| File / folder | Why |
|---|---|
| `artifacts/mockup-sandbox/` | Replit's internal design-preview tool. Not part of the deployed app (confirmed via its `kind = "design"` config and separate `/__mockup` preview path); never built or shipped. This folder is also why a GitHub language scan reported the repo as mostly Tailwind/TSX — it was the only place either technology existed. |
| `artifacts/computer-repair-tracker/components.json` | Leftover shadcn/ui scaffold config. Unused — no code imported it, and there was no `src/components/ui` folder in this artifact. |
| `.replit` | Replit-only hosting/workflow config. Ports and run commands it held are now documented in `README.md`. |
| `.replitignore` | Replit-only deployment image config; not needed elsewhere. |
| `artifacts/api-server/.replit-artifact/` | Replit-only per-artifact routing/build config. |
| `artifacts/computer-repair-tracker/.replit-artifact/` | Same as above. |
| `@replit/connectors-sdk` (root `package.json` dependency) | Not imported or used anywhere in the codebase. |

### Dependencies removed

- `@replit/connectors-sdk` (root `package.json`) — unused.

### Dependencies kept

- Everything in `artifacts/api-server` (Express, Drizzle ORM, cors,
  cookie-parser, pino/pino-http) — all actively used by the backend.
- Everything in `artifacts/computer-repair-tracker` (Vite only) — needed to
  serve/build the frontend.
- `lib/db`, `lib/api-zod` — used by the backend for schema and validation.
- `lib/api-client-react`, `lib/api-spec` — kept but unused by the current
  frontend; see the note in `README.md`.
- `pnpm-workspace.yaml`'s `minimumReleaseAge` supply-chain security setting
  — this is a general pnpm safety feature, not Replit-specific, so it was
  left in place.

### Replit-specific files kept (and why)

- None. All Replit-only files found were removed (see table above).
  `pnpm-workspace.yaml` was kept as-is because, aside from a couple of
  comments mentioning Replit, its content (workspace package list, the
  security setting, dependency overrides) is a normal pnpm configuration
  unrelated to Replit hosting.

### Known follow-up step

- `pnpm-lock.yaml` still references `@replit/connectors-sdk` (removed from
  `package.json`) and the deleted `mockup-sandbox` workspace package. There
  was no network access available in the environment this conversion was
  done in, so the lockfile could not be regenerated. Run `pnpm install`
  once (not `--frozen-lockfile`) after pulling this on a machine with
  internet access, so pnpm can update the lockfile to match. This does not
  affect any other dependency or any application code.

### Features preserved (verified by reading the code — see main report for
what could and could not be executed/tested in this environment)

- Dashboard stats (Pending / Diagnosing / Repairing / Ready / Completed)
- Add, view, edit, delete repair tickets
- Search (debounced) and status filter
- Dark/light theme toggle (saved to `localStorage`)
- Mobile sidebar menu
- Toast notifications, "back to top" button
- Database-backed storage via PostgreSQL + Drizzle ORM
